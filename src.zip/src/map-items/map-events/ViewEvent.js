import React from "react";
import MapContext from "../../context/mapContext";

export default class ViewEvent extends React.Component {
  static contextType = MapContext;
  constructor(props) {
    super(props);
    this.state = {};
  }

  componentDidMount() {
    
  }
  render() {
    return null;
  }
}
