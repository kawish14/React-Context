const Role =  {
    Admin: 'Admin',
    NOC:'NOC',
    SouthDEVuser:'SouthDEVuser',
    NorthDEVuser:'NorthDEVuser',
    CentralDEVuser:'CentralDEVuser',
    CSD:'CSD',

}

export default Role