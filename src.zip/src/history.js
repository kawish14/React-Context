const history = require("history").createBrowserHistory()
export default history;