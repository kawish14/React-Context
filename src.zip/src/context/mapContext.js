import { createContext } from "react";

const MapContext = createContext()

export default MapContext